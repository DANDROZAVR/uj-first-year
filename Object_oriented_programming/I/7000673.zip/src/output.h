#ifndef PO10_OUTPUT_HEADER
#define PO10_OUTPUT_HEADER
#include "result.h"

void print_result(Result r);

#endif

