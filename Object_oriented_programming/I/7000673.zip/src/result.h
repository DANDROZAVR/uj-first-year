#ifndef PO10_RESULT_HEADER
#define PO10_RESULT_HEADER

enum class Result {
  Invalid,
  Success,
  Failure
};

#endif

