#ifndef PO10_MAIN_HEADER
#define PO10_MAIN_HEADER

#include "result.h"
#include "galaxy.h"
#include "output.h"
#include "ship.h"

//Hero and Reaper classes need to be defined somewhere and their definitions must be included here
//Also include any other files that should be visible in order to use your classes
#endif

